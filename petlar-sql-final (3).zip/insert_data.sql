INSERT INTO ONG (nome, cnpj, telefone, cidade) VALUES
('Amigos dos Animais', '12.345.678/0001-90', '11988887777', 'São Paulo'),
('Patinhas Felizes', '98.765.432/0001-10', '21999996666', 'Rio de Janeiro');

INSERT INTO Adotante (nome, email, telefone, cidade) VALUES
('Maria Silva', 'maria@gmail.com', '11911112222', 'São Paulo'),
('João Pereira', 'joao@gmail.com', '21922223333', 'Rio de Janeiro'),
('Ana Costa', 'ana@gmail.com', '31933334444', 'Belo Horizonte');

INSERT INTO Animal (nome, especie, idade, status_adocao, id_ong) VALUES
('Bidu', 'Cachorro', 3, 'Disponível', 1),
('Mia', 'Gato', 2, 'Disponível', 1),
('Thor', 'Cachorro', 5, 'Disponível', 2),
('Luna', 'Gato', 1, 'Adotado', 2);

INSERT INTO Adocao (data_adocao, id_animal, id_adotante) VALUES
('2024-10-10', 4, 2);
