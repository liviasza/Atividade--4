SELECT nome, especie, idade
FROM Animal
WHERE status_adocao = 'Disponível';

SELECT nome, especie, idade
FROM Animal
ORDER BY idade DESC;

SELECT nome, especie
FROM Animal
LIMIT 2;

SELECT A.nome AS Animal, AD.nome AS Adotante, O.nome AS ONG, AC.data_adocao
FROM Adocao AC
JOIN Animal A ON A.id_animal = AC.id_animal
JOIN Adotante AD ON AD.id_adotante = AC.id_adotante
JOIN ONG O ON O.id_ong = A.id_ong;

SELECT A.nome, A.especie, O.nome AS ONG
FROM Animal A
JOIN ONG O ON O.id_ong = A.id_ong
WHERE O.nome = 'Amigos dos Animais';
