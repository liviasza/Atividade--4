# 🐾 PetLar – Projeto SQL (Atividade Prática 4)

Este repositório contém os scripts SQL desenvolvidos para o projeto **PetLar**, uma plataforma que conecta ONGs de proteção animal a possíveis adotantes.

## 📂 Conteúdo
- create_tables.sql — criação completa das tabelas
- insert_data.sql — povoamento das tabelas
- select_queries.sql — consultas SQL com JOIN, WHERE, ORDER BY, LIMIT
- update_delete.sql — comandos de atualização e remoção
- der_petlar.png — diagrama do modelo lógico

## ▶️ Execução
1. CREATE DATABASE petlar;
2. Rode create_tables.sql
3. Rode insert_data.sql
4. execute select_queries.sql
5. execute update_delete.sql
