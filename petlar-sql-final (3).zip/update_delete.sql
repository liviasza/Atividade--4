UPDATE Animal
SET status_adocao = 'Adotado'
WHERE id_animal = 1;

UPDATE Adotante
SET telefone = '11955556666'
WHERE id_adotante = 1;

UPDATE ONG
SET cidade = 'Campinas'
WHERE id_ong = 1;

DELETE FROM Adocao
WHERE id_adocao = 1;

DELETE FROM Animal
WHERE id_animal = 3;

DELETE FROM Adotante
WHERE id_adotante = 3;
